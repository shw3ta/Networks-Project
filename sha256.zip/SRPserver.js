function SRP6JavascriptServerSessionSHA256(){ }

SRP6JavascriptServerSessionSHA256.prototype = new SRP6JavascriptServerSession();

SRP6JavascriptServerSessionSHA256.prototype.N = new BigInteger(SRP6CryptoParams.N_base10, 10);


SRP6JavascriptServerSessionSHA256.prototype.g = new BigInteger(SRP6CryptoParams.g_base10, 10);


SRP6JavascriptServerSessionSHA256.prototype.H = function (x) {
		return CryptoJS.SHA256(x).toString().toLowerCase();
}

SRP6JavascriptServerSessionSHA256.prototype.k = new BigInteger(SRP6CryptoParams.k_base16, 16);